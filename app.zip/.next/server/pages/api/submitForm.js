"use strict";(()=>{var e={};e.id=795,e.ids=[795],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},1915:(e,t,r)=>{r.r(t),r.d(t,{config:()=>p,default:()=>d,routeModule:()=>m});var n={};r.r(n),r.d(n,{default:()=>c});var a=r(1802),i=r(7153),o=r(6249);let u=require("mssql");var s=r.n(u);let l={user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_DATABASE,server:process.env.DB_SERVER,pool:{max:10,min:0,idleTimeoutMillis:3e4},options:{encrypt:!0,trustServerCertificate:!1}},c=async function(e,t){if("POST"===e.method)try{let{createdBy:r,email:n,observationDate:a,category:i,department:o,subDepartment:u,descriptionOfIncident:c,correction:d,correctiveAction:p,linkToReleventDocument:m,directCauseOther:C,underlyingCauseOther:b,subCategoryDirectCause:A,subCategoryUnderlyingCause:h}=e.body,y=i?i.label:null,f=o?o.label:null,g=u?u.label:null,P=A?A.label:null,v=h?h.label:null;await s().connect(l);let D=new(s()).Request;D.input("createdBy",s().NVarChar(255),r),D.input("email",s().NVarChar(255),n),D.input("observationDate",s().Date,new Date(a)),D.input("category",s().NVarChar(255),y),D.input("department",s().NVarChar(255),f),D.input("subDepartment",s().NVarChar(255),g),D.input("descriptionOfIncident",s().NVarChar(s().MAX),c),D.input("correction",s().NVarChar(s().MAX),d),D.input("correctiveAction",s().NVarChar(s().MAX),p),D.input("linkToReleventDocument",s().NVarChar(s().MAX),m),D.input("directCauseOther",s().NVarChar(255),C),D.input("underlyingCauseOther",s().NVarChar(255),b),D.input("subCategoryDirectCause",s().NVarChar(255),P),D.input("subCategoryUnderlyingCause",s().NVarChar(255),v);let O=await D.query(`
        INSERT INTO devnci (
          createdBy,
          email,
          observationDate,
          category,
          department,
          subDepartment,
          descriptionOfIncident,
          correction,
          correctiveAction,
          linkToReleventDocument,
          directCauseOther,
          underlyingCauseOther,
          subCategoryDirectCause,
          subCategoryUnderlyingCause
        ) VALUES (
          @createdBy,
          @email,
          @observationDate,
          @category,
          @department,
          @subDepartment,
          @descriptionOfIncident,
          @correction,
          @correctiveAction,
          @linkToReleventDocument,
          @directCauseOther,
          @underlyingCauseOther,
          @subCategoryDirectCause,
          @subCategoryUnderlyingCause
        )
      `);await s().close(),t.status(200).json({message:"Form submitted successfully",data:O.recordset})}catch(e){console.error("SQL error",e),t.status(500).json({message:"Error submitting form",error:e.message})}else t.setHeader("Allow",["POST"]),t.status(405).end(`Method ${e.method} Not Allowed`)},d=(0,o.l)(n,"default"),p=(0,o.l)(n,"config"),m=new a.PagesAPIRouteModule({definition:{kind:i.x.PAGES_API,page:"/api/submitForm",pathname:"/api/submitForm",bundlePath:"",filename:""},userland:n})},7153:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},1802:(e,t,r)=>{e.exports=r(145)}};var t=require("../../webpack-api-runtime.js");t.C(e);var r=t(t.s=1915);module.exports=r})();